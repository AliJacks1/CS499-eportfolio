import sqlite3

conn = sqlite3.connect("sales.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    name TEXT,
    region TEXT,
    revenue REAL,
    returns INTEGER
)
""")

products_data = [
    ("Protein Powder", "North", 5000, 5),
    ("Vitamins", "South", 3200, 2),
    ("Energy Drink", "West", 4100, 7),
    ("Yoga Mat", "East", 2800, 1),
    ("Protein Bars", "North", 3900, 4)
]

cursor.executemany("INSERT INTO products (name, region, revenue, returns) VALUES (?, ?, ?, ?)", products_data)

conn.commit()

print("\nTop Revenue Products:")
cursor.execute("SELECT name, revenue FROM products ORDER BY revenue DESC")
for row in cursor.fetchall():
    print(row)

print("\nRevenue by Region:")
cursor.execute("SELECT region, SUM(revenue) FROM products GROUP BY region")
for row in cursor.fetchall():
    print(row)

print("\nProducts with High Returns:")
cursor.execute("SELECT name, returns FROM products WHERE returns > 3")
for row in cursor.fetchall():
    print(row)

conn.close()