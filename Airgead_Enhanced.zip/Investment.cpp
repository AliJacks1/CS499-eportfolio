#include <iostream>
#include <iomanip>
#include "Investment.h"

using namespace std;

// Constructor
Investment::Investment(double initialInv, double monthlyDep, double interestRate, int years)
    : initialInvestment(initialInv), monthlyDeposit(monthlyDep), annualInterest(interestRate), numYears(years) {}

// Getter methods
double Investment::getInitialInvestment() const {
    return initialInvestment;
}

double Investment::getMonthlyDeposit() const {
    return monthlyDeposit;
}

double Investment::getAnnualInterest() const {
    return annualInterest;
}

int Investment::getNumYears() const {
    return numYears;
}

// Calculates yearly balances without monthly deposits
void Investment::calculateWithoutMonthlyDeposits() const {
    double balance = initialInvestment;
    double interest = 0.0;

    cout << fixed << setprecision(2);

    cout << "\nYear-End Balances Without Additional Monthly Deposits:\n";
    cout << "Year   Year-End Balance   Year-End Earned Interest\n";
    cout << "---------------------------------------------------\n";

    for (int year = 1; year <= numYears; ++year) {
        // Calculate yearly interest based on the current balance
        interest = balance * (annualInterest / 100.0);

        // Update the balance after adding the yearly interest
        balance += interest;

        // Display results for the current year
        cout << setw(4) << year
             << setw(18) << balance
             << setw(26) << interest << "\n";
    }
}

// Calculates yearly balances with monthly deposits
void Investment::calculateWithMonthlyDeposits() const {
    double balance = initialInvestment;
    double interest = 0.0;

    cout << fixed << setprecision(2);

    cout << "\nYear-End Balances With Additional Monthly Deposits:\n";
    cout << "Year   Year-End Balance   Year-End Earned Interest\n";
    cout << "---------------------------------------------------\n";

    for (int year = 1; year <= numYears; ++year) {
        double yearInterest = 0.0;

        for (int month = 1; month <= 12; ++month) {
            // Monthly interest is calculated after the monthly deposit is added
            interest = (balance + monthlyDeposit) * ((annualInterest / 100.0) / 12.0);

            // Track total interest earned for the current year
            yearInterest += interest;

            // Update balance with monthly deposit and earned interest
            balance += monthlyDeposit + interest;
        }

        // Display results for the current year
        cout << setw(4) << year
             << setw(18) << balance
             << setw(26) << yearInterest << "\n";
    }
}