#include <iostream>
#include <limits>
#include <string>
#include "Investment.h"

using namespace std;

// Validate non-negative decimal input
double getValidatedDouble(const string& prompt) {
    double value;

    while (true) {
        cout << prompt;
        cin >> value;

        if (cin.fail() || value < 0) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a non-negative number.\n";
        } else {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
    }
}

// Validate non-negative integer input
int getValidatedInt(const string& prompt) {
    int value;

    while (true) {
        cout << prompt;
        cin >> value;

        if (cin.fail() || value < 0) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a non-negative whole number.\n";
        } else {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
    }
}

int main() {
    char choice;

    do {
        double initialInvestment;
        double monthlyDeposit;
        double annualInterest;
        int numYears;

        cout << "Welcome to Airgead Banking Investment Calculator!\n\n";

        // Get validated user input
        initialInvestment = getValidatedDouble("Enter the Initial Investment Amount: $");
        monthlyDeposit = getValidatedDouble("Enter the Monthly Deposit: $");
        annualInterest = getValidatedDouble("Enter the Annual Interest Rate (as a percentage): ");
        numYears = getValidatedInt("Enter the Number of Years: ");

        // Confirm input
        cout << "\nInitial Investment Amount: $" << initialInvestment << "\n";
        cout << "Monthly Deposit: $" << monthlyDeposit << "\n";
        cout << "Annual Interest Rate: " << annualInterest << "%\n";
        cout << "Number of Years: " << numYears << "\n";

        cout << "\nPress Enter to continue...";
        cin.get();

        // Create Investment object
        Investment investment(initialInvestment, monthlyDeposit, annualInterest, numYears);

        // Generate reports
        investment.calculateWithoutMonthlyDeposits();
        investment.calculateWithMonthlyDeposits();

        cout << "\nWould you like to run another scenario? (y/n): ";
        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "\n";

    } while (choice == 'y' || choice == 'Y');

    cout << "Thank you for using Airgead Banking Investment Calculator!\n";
    return 0;
}